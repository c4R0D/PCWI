# sr
静态网站留言板  
评论系统  
仍处于开发阶段  
### 
```
使用方法  
<iframe src="https://axutebils74.github.io/sr/#test" frameborder="0" width="360px" height="500px"></iframe>  
改变 URL 中 # 符号后的标识进入不同的频道
```
# 引用
### lz-string
[https://github.com/pieroxy/lz-string](https://github.com/pieroxy/lz-string)
### md5
[https://github.com/emn178/js-md5](https://github.com/emn178/js-md5)
### mimc
[https://github.com/Xiaomi-mimc/mimc-webjs-sdk](https://github.com/Xiaomi-mimc/mimc-webjs-sdk)   
[https://admin.mimc.chat.xiaomi.net/docs/0403-webjs.html](https://admin.mimc.chat.xiaomi.net/docs/0403-webjs.html)
### 头像
[https://github.com/KUN1007/kungalgame-stickers](https://github.com/KUN1007/kungalgame-stickers)
